import React from 'react';

interface AvatarProps {
  isTalking: boolean;
}

const IDLE_GIF = '';
const TALKING_GIF = '';


const Avatar: React.FC<AvatarProps> = ({ isTalking }) => {
  return (
    <div className="flex justify-center items-center h-40 w-40">
       <img 
        src={isTalking ? TALKING_GIF : IDLE_GIF} 
        alt="AI Robot Avatar" 
        className="w-full h-full object-contain transition-transform duration-300 ease-in-out"
        style={{ transform: isTalking ? 'scale(1.1)' : 'scale(1)' }}
      />
    </div>
  );
};

export default Avatar;